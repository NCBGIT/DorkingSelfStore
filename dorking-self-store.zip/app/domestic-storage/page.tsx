import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Check } from "lucide-react"
import CTABanner from "@/components/cta-banner"
import EnquiryForm from "@/components/enquiry-form"
import TestimonialSlider from "@/components/testimonial-slider"

export default function DomesticStoragePage() {
  return (
    <>
      {/* Hero Section */}
      <section className="bg-muted py-12 md:py-16">
        <div className="container">
          <div className="grid gap-8 lg:grid-cols-2">
            <div>
              <h1 className="mb-4 text-4xl font-bold tracking-tight md:text-5xl">
                Domestic Storage Solutions
                <span className="mt-2 block text-secondary">First Month Free</span>
              </h1>

              <p className="mb-6 text-lg text-muted-foreground">
                Secure, flexible storage for homeowners, movers, and renovators. Create more space in your home or
                safely store your belongings during transitions.
              </p>

              <ul className="mb-6 space-y-2">
                <li className="flex items-center gap-2">
                  <Check className="h-5 w-5 text-secondary" />
                  <span>Clean, dry, and secure units</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="h-5 w-5 text-secondary" />
                  <span>Climate-controlled environment</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="h-5 w-5 text-secondary" />
                  <span>Flexible access hours</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="h-5 w-5 text-secondary" />
                  <span>Collection and delivery service available</span>
                </li>
              </ul>

              <Button asChild size="lg">
                <a href="tel:01306880124">Call to Reserve: 01306 880124</a>
              </Button>
            </div>

            <div className="relative h-[300px] overflow-hidden rounded-lg md:h-[400px]">
              <Image
                src="/placeholder.svg?height=400&width=600"
                alt="Domestic storage solutions"
                fill
                className="object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Domestic Storage Benefits */}
      <section className="py-12 md:py-16">
        <div className="container">
          <h2 className="mb-8 text-center text-3xl font-bold">Perfect For Your Home</h2>

          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            <div className="rounded-lg border bg-card p-6 shadow-sm">
              <h3 className="mb-4 text-xl font-bold">Moving House</h3>
              <p className="mb-4">
                Store your belongings safely during the transition between properties, reducing stress on moving day.
              </p>
              <Image
                src="/placeholder.svg?height=200&width=300"
                alt="Moving house storage"
                width={300}
                height={200}
                className="rounded-lg"
              />
            </div>

            <div className="rounded-lg border bg-card p-6 shadow-sm">
              <h3 className="mb-4 text-xl font-bold">Home Renovations</h3>
              <p className="mb-4">Keep your furniture and possessions safe and clean while you renovate your home.</p>
              <Image
                src="/placeholder.svg?height=200&width=300"
                alt="Home renovation storage"
                width={300}
                height={200}
                className="rounded-lg"
              />
            </div>

            <div className="rounded-lg border bg-card p-6 shadow-sm">
              <h3 className="mb-4 text-xl font-bold">Decluttering</h3>
              <p className="mb-4">
                Create more space in your home by storing seasonal items, sports equipment, or rarely used possessions.
              </p>
              <Image
                src="/placeholder.svg?height=200&width=300"
                alt="Decluttering storage"
                width={300}
                height={200}
                className="rounded-lg"
              />
            </div>

            <div className="rounded-lg border bg-card p-6 shadow-sm">
              <h3 className="mb-4 text-xl font-bold">Student Storage</h3>
              <p className="mb-4">
                Store your belongings during university holidays instead of transporting everything home.
              </p>
              <Image
                src="/placeholder.svg?height=200&width=300"
                alt="Student storage"
                width={300}
                height={200}
                className="rounded-lg"
              />
            </div>

            <div className="rounded-lg border bg-card p-6 shadow-sm">
              <h3 className="mb-4 text-xl font-bold">Downsizing</h3>
              <p className="mb-4">
                Keep treasured possessions safe when moving to a smaller property until you decide what to do with them.
              </p>
              <Image
                src="/placeholder.svg?height=200&width=300"
                alt="Downsizing storage"
                width={300}
                height={200}
                className="rounded-lg"
              />
            </div>

            <div className="rounded-lg border bg-card p-6 shadow-sm">
              <h3 className="mb-4 text-xl font-bold">Seasonal Storage</h3>
              <p className="mb-4">
                Store seasonal items like Christmas decorations, garden furniture, or winter clothes when not in use.
              </p>
              <Image
                src="/placeholder.svg?height=200&width=300"
                alt="Seasonal storage"
                width={300}
                height={200}
                className="rounded-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Peace of Mind Section */}
      <section className="bg-muted py-12 md:py-16">
        <div className="container">
          <div className="grid gap-8 md:grid-cols-2">
            <div className="flex flex-col justify-center">
              <h2 className="mb-4 text-3xl font-bold">Peace of Mind Storage</h2>
              <p className="mb-6">
                At Dorking Self Store, we understand that your possessions are valuable and important to you. That's why
                we provide:
              </p>

              <ul className="mb-6 space-y-3">
                <li className="flex items-start gap-2">
                  <Check className="mt-1 h-5 w-5 flex-shrink-0 text-secondary" />
                  <span>24/7 CCTV monitoring and security systems to keep your belongings safe</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="mt-1 h-5 w-5 flex-shrink-0 text-secondary" />
                  <span>Climate-controlled units to protect sensitive items from humidity and temperature changes</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="mt-1 h-5 w-5 flex-shrink-0 text-secondary" />
                  <span>Fire detection and prevention systems throughout the facility</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="mt-1 h-5 w-5 flex-shrink-0 text-secondary" />
                  <span>Insurance options to give you extra protection and peace of mind</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="mt-1 h-5 w-5 flex-shrink-0 text-secondary" />
                  <span>Friendly, professional staff who care about your storage needs</span>
                </li>
              </ul>
            </div>

            <div className="relative h-[300px] overflow-hidden rounded-lg md:h-[400px]">
              <Image
                src="/placeholder.svg?height=400&width=600"
                alt="Secure storage facility"
                fill
                className="object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Convenience Features */}
      <section className="py-12 md:py-16">
        <div className="container">
          <h2 className="mb-8 text-center text-3xl font-bold">Making Storage Easy</h2>

          <div className="grid gap-8 md:grid-cols-2">
            <div className="rounded-lg border bg-card p-6 shadow-sm">
              <h3 className="mb-4 text-xl font-bold">Collection & Delivery Service</h3>
              <p className="mb-4">
                Don't have transport? No problem. We offer a convenient collection and delivery service to make your
                storage experience hassle-free.
              </p>
              <Image
                src="/placeholder.svg?height=200&width=400"
                alt="Collection and delivery service"
                width={400}
                height={200}
                className="rounded-lg"
              />
            </div>

            <div className="rounded-lg border bg-card p-6 shadow-sm">
              <h3 className="mb-4 text-xl font-bold">Packing Supplies Available</h3>
              <p className="mb-4">
                We stock a range of packing materials including boxes, bubble wrap, tape, and protective covers to help
                you pack your items safely.
              </p>
              <Image
                src="/placeholder.svg?height=200&width=400"
                alt="Packing supplies"
                width={400}
                height={200}
                className="rounded-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="bg-muted py-12 md:py-16">
        <div className="container">
          <h2 className="mb-8 text-center text-3xl font-bold">What Our Customers Say</h2>
          <TestimonialSlider className="mx-auto max-w-3xl" />
        </div>
      </section>

      {/* Enquiry Form */}
      <section className="py-12 md:py-16">
        <div className="container">
          <div className="mx-auto max-w-2xl">
            <h2 className="mb-8 text-center text-3xl font-bold">Get in Touch</h2>
            <EnquiryForm />
          </div>
        </div>
      </section>

      {/* CTA Banner */}
      <CTABanner
        title="Need Home Storage? Call Us Today!"
        subtitle="Speak to our friendly team about your domestic storage needs"
      />
    </>
  )
}
