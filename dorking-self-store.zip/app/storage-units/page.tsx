import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Check, Calculator, ArrowUpDownIcon as ArrowsUpDown } from "lucide-react"
import CTABanner from "@/components/cta-banner"
import StorageUnitCard from "@/components/storage-unit-card"
import EnquiryForm from "@/components/enquiry-form"

export default function StorageUnitsPage() {
  return (
    <>
      {/* Hero Section */}
      <section className="bg-muted py-12 md:py-16">
        <div className="container">
          <div className="grid gap-8 lg:grid-cols-2">
            <div>
              <h1 className="mb-4 text-4xl font-bold tracking-tight md:text-5xl">
                Storage Units
                <span className="mt-2 block text-secondary">First Month Free</span>
              </h1>

              <p className="mb-6 text-lg text-muted-foreground">
                We offer a range of storage unit sizes to suit your needs, whether you're storing a few boxes or the
                contents of a large house.
              </p>

              <ul className="mb-6 space-y-2">
                <li className="flex items-center gap-2">
                  <Check className="h-5 w-5 text-secondary" />
                  <span>Secure, climate-controlled units</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="h-5 w-5 text-secondary" />
                  <span>24/7 CCTV monitoring</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="h-5 w-5 text-secondary" />
                  <span>Flexible contract terms</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="h-5 w-5 text-secondary" />
                  <span>First month free for new customers</span>
                </li>
              </ul>

              <div className="flex flex-col gap-4 sm:flex-row">
                <Button asChild size="lg">
                  <a href="tel:01306880124">Call to Reserve: 01306 880124</a>
                </Button>

                <Button asChild variant="outline" size="lg">
                  <Link href="/size-calculator">Size Calculator</Link>
                </Button>
              </div>
            </div>

            <div className="relative h-[300px] overflow-hidden rounded-lg md:h-[400px]">
              <Image
                src="/placeholder.svg?height=400&width=600"
                alt="Dorking Self Store units"
                fill
                className="object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Storage Units */}
      <section className="py-12 md:py-16">
        <div className="container">
          <div className="mb-8 flex flex-col items-center justify-between gap-4 sm:flex-row">
            <h2 className="text-center text-3xl font-bold sm:text-left">Our Storage Unit Sizes</h2>
            <div className="flex gap-3">
              <Button asChild variant="outline" size="sm" className="gap-2">
                <Link href="/size-calculator">
                  <Calculator className="h-4 w-4" />
                  <span>Size Calculator</span>
                </Link>
              </Button>
              <Button asChild variant="outline" size="sm" className="gap-2">
                <Link href="/compare-units">
                  <ArrowsUpDown className="h-4 w-4" />
                  <span>Compare Units</span>
                </Link>
              </Button>
            </div>
          </div>

          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            <StorageUnitCard
              size="Small Unit"
              dimensions="25 sq ft (5ft × 5ft)"
              price="£85"
              description="Perfect for small household items, seasonal decorations, or business documents."
              imageSrc="/placeholder.svg?height=300&width=400"
            />

            <StorageUnitCard
              size="Medium Unit"
              dimensions="50 sq ft (10ft × 5ft)"
              price="£157"
              description="Ideal for the contents of a one-bedroom flat or small office equipment."
              imageSrc="/placeholder.svg?height=300&width=400"
              popular
            />

            <StorageUnitCard
              size="Large Unit"
              dimensions="100 sq ft (10ft × 10ft)"
              price="£295"
              description="Suitable for the contents of a three-bedroom house or larger business inventory."
              imageSrc="/placeholder.svg?height=300&width=400"
            />

            <StorageUnitCard
              size="Extra Large Unit"
              dimensions="150 sq ft (15ft × 10ft)"
              price="£425"
              description="Perfect for the contents of a four-bedroom house or substantial business storage needs."
              imageSrc="/placeholder.svg?height=300&width=400"
            />

            <StorageUnitCard
              size="Garage Unit"
              dimensions="200 sq ft (20ft × 10ft)"
              price="£550"
              description="Our largest unit, suitable for house moves, large furniture items, or extensive business storage."
              imageSrc="/placeholder.svg?height=300&width=400"
            />

            <StorageUnitCard
              size="Custom Solution"
              dimensions="Tailored to your needs"
              price="Contact us"
              description="Need something specific? We can create a custom storage solution to meet your exact requirements."
              imageSrc="/placeholder.svg?height=300&width=400"
            />
          </div>
        </div>
      </section>

      {/* What Fits Guide */}
      <section className="bg-muted py-12 md:py-16">
        <div className="container">
          <h2 className="mb-8 text-center text-3xl font-bold">What Fits in Each Unit?</h2>

          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Unit Size</TableHead>
                  <TableHead>Dimensions</TableHead>
                  <TableHead>Typical Contents</TableHead>
                  <TableHead className="text-right">Price</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow>
                  <TableCell className="font-medium">Small</TableCell>
                  <TableCell>25 sq ft (5ft × 5ft)</TableCell>
                  <TableCell>Small furniture items, boxes, seasonal items</TableCell>
                  <TableCell className="text-right">£85/month</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell className="font-medium">Medium</TableCell>
                  <TableCell>50 sq ft (10ft × 5ft)</TableCell>
                  <TableCell>Contents of a one-bedroom flat</TableCell>
                  <TableCell className="text-right">£157/month</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell className="font-medium">Large</TableCell>
                  <TableCell>100 sq ft (10ft × 10ft)</TableCell>
                  <TableCell>Contents of a three-bedroom house</TableCell>
                  <TableCell className="text-right">£295/month</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell className="font-medium">Extra Large</TableCell>
                  <TableCell>150 sq ft (15ft × 10ft)</TableCell>
                  <TableCell>Contents of a four-bedroom house</TableCell>
                  <TableCell className="text-right">£425/month</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell className="font-medium">Garage</TableCell>
                  <TableCell>200 sq ft (20ft × 10ft)</TableCell>
                  <TableCell>Full house contents, large furniture items</TableCell>
                  <TableCell className="text-right">£550/month</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </div>

          <div className="mt-8 text-center">
            <p className="mb-4 text-muted-foreground">
              Not sure which size you need? Call us for advice or use our handy size calculator.
            </p>

            <div className="flex flex-col justify-center gap-4 sm:flex-row">
              <Button asChild>
                <a href="tel:01306880124">Call for Advice: 01306 880124</a>
              </Button>

              <Button asChild variant="outline" className="gap-2">
                <Link href="/size-calculator">
                  <Calculator className="h-4 w-4" />
                  <span>Size Calculator</span>
                </Link>
              </Button>

              <Button asChild variant="outline" className="gap-2">
                <Link href="/compare-units">
                  <ArrowsUpDown className="h-4 w-4" />
                  <span>Compare Units</span>
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* First Month Free Promo */}
      <section className="py-12 md:py-16">
        <div className="container">
          <div className="grid gap-8 rounded-lg border bg-card p-8 shadow-lg md:grid-cols-2">
            <div>
              <h2 className="mb-4 text-3xl font-bold">
                First Month <span className="text-secondary">FREE</span>
              </h2>

              <p className="mb-6">
                We're offering your first month of storage absolutely free when you sign up for any of our storage
                units. This special offer is perfect for:
              </p>

              <ul className="mb-6 space-y-2">
                <li className="flex items-center gap-2">
                  <Check className="h-5 w-5 text-secondary" />
                  <span>Home movers needing temporary storage</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="h-5 w-5 text-secondary" />
                  <span>Businesses looking to expand their storage space</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="h-5 w-5 text-secondary" />
                  <span>Homeowners decluttering or renovating</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="h-5 w-5 text-secondary" />
                  <span>Anyone needing secure, climate-controlled storage</span>
                </li>
              </ul>

              <Button asChild size="lg">
                <a href="tel:01306880124">Claim Your Free Month Now</a>
              </Button>
            </div>

            <div className="flex items-center justify-center">
              <div className="relative h-[300px] w-full overflow-hidden rounded-lg">
                <Image
                  src="/images/first-month-free.jpg"
                  alt="First month free promotion with storage unit and boxes"
                  fill
                  className="object-cover"
                  priority
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Enquiry Form */}
      <section className="bg-muted py-12 md:py-16">
        <div className="container">
          <div className="mx-auto max-w-2xl">
            <h2 className="mb-8 text-center text-3xl font-bold">Reserve Your Storage Unit</h2>
            <EnquiryForm />
          </div>
        </div>
      </section>

      {/* CTA Banner */}
      <CTABanner />
    </>
  )
}
