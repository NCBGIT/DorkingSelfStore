import type { Metadata } from "next"
import UnitComparison from "@/components/unit-comparison"
import CTABanner from "@/components/cta-banner"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Calculator } from "lucide-react"

export const metadata: Metadata = {
  title: "Compare Storage Units | Dorking Self Store",
  description:
    "Compare our different storage unit sizes side by side to find the perfect solution for your storage needs.",
}

export default function CompareUnitsPage() {
  return (
    <>
      {/* Hero Section */}
      <section className="bg-muted py-12 md:py-16">
        <div className="container">
          <div className="mx-auto max-w-3xl text-center">
            <h1 className="mb-4 text-4xl font-bold tracking-tight md:text-5xl">Compare Storage Units</h1>
            <p className="mb-6 text-lg text-muted-foreground">
              Compare our different storage unit sizes side by side to find the perfect solution for your storage needs.
            </p>
          </div>
        </div>
      </section>

      {/* Comparison Section */}
      <section className="py-12 md:py-16">
        <div className="container">
          <UnitComparison />

          <div className="mt-12 text-center">
            <p className="mb-4 text-muted-foreground">
              Not sure how much space you need? Use our interactive size calculator to get a personalized
              recommendation.
            </p>
            <Button asChild className="gap-2">
              <Link href="/size-calculator">
                <Calculator className="h-4 w-4" />
                <span>Storage Size Calculator</span>
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* CTA Banner */}
      <CTABanner
        title="Need Help Choosing a Storage Unit?"
        subtitle="Our friendly team is ready to assist you with personalized advice"
      />
    </>
  )
}
