import type React from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Check, Lock, Truck, Banknote, Home, Briefcase, Award } from "lucide-react"
import CTABanner from "@/components/cta-banner"
import EnquiryForm from "@/components/enquiry-form"

interface USPSectionProps {
  icon: React.ReactNode
  title: string
  description: string
  imageSrc: string
}

function USPSection({ icon, title, description, imageSrc }: USPSectionProps) {
  return (
    <div className="grid gap-8 md:grid-cols-2">
      <div className="flex flex-col justify-center">
        <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 text-primary">
          {icon}
        </div>
        <h3 className="mb-4 text-2xl font-bold">{title}</h3>
        <p className="text-muted-foreground">{description}</p>
      </div>

      <div className="relative h-[250px] overflow-hidden rounded-lg md:h-[300px]">
        <Image src={imageSrc || "/placeholder.svg"} alt={title} fill className="object-cover" />
      </div>
    </div>
  )
}

export default function WhyChooseUsPage() {
  return (
    <>
      {/* Hero Section */}
      <section className="bg-muted py-12 md:py-16">
        <div className="container">
          <div className="mx-auto max-w-3xl text-center">
            <h1 className="mb-4 text-4xl font-bold tracking-tight md:text-5xl">Why Choose Dorking Self Store?</h1>

            <p className="mb-6 text-lg text-muted-foreground">
              Discover what makes us the preferred storage solution in Dorking and the surrounding areas.
            </p>
          </div>
        </div>
      </section>

      {/* USP Sections */}
      <section className="py-12 md:py-16">
        <div className="container">
          <div className="space-y-16">
            <USPSection
              icon={<Lock className="h-6 w-6" />}
              title="High-Quality, Secure Facility"
              description="Our storage facility is equipped with 24/7 CCTV monitoring, individual unit alarms, secure access control, and fire protection systems. We've invested in top-quality security measures to ensure your belongings are safe and protected at all times."
              imageSrc="/placeholder.svg?height=300&width=500"
            />

            <USPSection
              icon={<Truck className="h-6 w-6" />}
              title="Collection & Delivery Service"
              description="Don't have transport? No problem. Our convenient collection and delivery service makes storing your items hassle-free. We'll collect your belongings from your home or business, transport them safely to our facility, and deliver them back to you when you need them."
              imageSrc="/placeholder.svg?height=300&width=500"
            />

            <USPSection
              icon={<Banknote className="h-6 w-6" />}
              title="First Month Free Offer"
              description="We're so confident you'll love our storage solutions that we offer your first month absolutely free. This gives you the chance to experience our service without a significant upfront commitment, and helps spread the cost of your storage needs."
              imageSrc="/placeholder.svg?height=300&width=500"
            />

            <USPSection
              icon={<Home className="h-6 w-6" />}
              title="Homeowner & Small Business Friendly"
              description="Whether you're a homeowner looking to declutter, a family in the midst of moving house, or a small business needing extra space for inventory, our flexible storage solutions are designed to meet your specific needs. We offer a range of unit sizes and flexible terms."
              imageSrc="/placeholder.svg?height=300&width=500"
            />

            <USPSection
              icon={<Briefcase className="h-6 w-6" />}
              title="High Conversion & Satisfaction"
              description="Our customers consistently rate us highly for our service, security, and value for money. We pride ourselves on our high customer satisfaction rates and the number of customers who choose us over national chains or container yards."
              imageSrc="/placeholder.svg?height=300&width=500"
            />

            <USPSection
              icon={<Award className="h-6 w-6" />}
              title="Local, Trusted, Personal"
              description="As a local, family-run business, we provide a personal service that large national chains simply can't match. We know the Dorking area well and understand the storage needs of local residents and businesses. Our friendly team is always on hand to help."
              imageSrc="/placeholder.svg?height=300&width=500"
            />
          </div>
        </div>
      </section>

      {/* Why We're Better Section */}
      <section className="bg-muted py-12 md:py-16">
        <div className="container">
          <h2 className="mb-8 text-center text-3xl font-bold">Why We're Better Than The Rest</h2>

          <div className="grid gap-8 md:grid-cols-2">
            <div className="rounded-lg bg-card p-6 shadow-sm">
              <h3 className="mb-4 text-xl font-bold">Dorking Self Store vs. National Chains</h3>

              <ul className="space-y-3">
                <li className="flex items-start gap-2">
                  <Check className="mt-1 h-5 w-5 flex-shrink-0 text-secondary" />
                  <span>Personal service from a team who knows you by name</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="mt-1 h-5 w-5 flex-shrink-0 text-secondary" />
                  <span>No hidden fees or complicated pricing structures</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="mt-1 h-5 w-5 flex-shrink-0 text-secondary" />
                  <span>Flexible terms without long-term commitments</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="mt-1 h-5 w-5 flex-shrink-0 text-secondary" />
                  <span>First month free offer that actually delivers value</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="mt-1 h-5 w-5 flex-shrink-0 text-secondary" />
                  <span>Local knowledge and understanding of your needs</span>
                </li>
              </ul>
            </div>

            <div className="rounded-lg bg-card p-6 shadow-sm">
              <h3 className="mb-4 text-xl font-bold">Dorking Self Store vs. Container Yards</h3>

              <ul className="space-y-3">
                <li className="flex items-start gap-2">
                  <Check className="mt-1 h-5 w-5 flex-shrink-0 text-secondary" />
                  <span>Clean, dry, climate-controlled environment</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="mt-1 h-5 w-5 flex-shrink-0 text-secondary" />
                  <span>Superior security with 24/7 monitoring</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="mt-1 h-5 w-5 flex-shrink-0 text-secondary" />
                  <span>Protection from damp, pests, and extreme temperatures</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="mt-1 h-5 w-5 flex-shrink-0 text-secondary" />
                  <span>Convenient access hours in a well-lit facility</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="mt-1 h-5 w-5 flex-shrink-0 text-secondary" />
                  <span>Collection and delivery service available</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-12 md:py-16">
        <div className="container">
          <div className="grid gap-8 rounded-lg border bg-card p-8 shadow-lg md:grid-cols-2">
            <div>
              <h2 className="mb-4 text-3xl font-bold">
                Get Your <span className="text-secondary">Free Month</span> Today
              </h2>

              <p className="mb-6">
                Experience the Dorking Self Store difference with our special first month free offer. Contact us today
                to:
              </p>

              <ul className="mb-6 space-y-2">
                <li className="flex items-center gap-2">
                  <Check className="h-5 w-5 text-secondary" />
                  <span>Discuss your storage needs</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="h-5 w-5 text-secondary" />
                  <span>Get expert advice on the right unit size</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="h-5 w-5 text-secondary" />
                  <span>Learn about our security features</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="h-5 w-5 text-secondary" />
                  <span>Arrange a visit to our facility</span>
                </li>
              </ul>

              <Button asChild size="lg">
                <a href="tel:01306880124">Speak to Our Team: 01306 880124</a>
              </Button>
            </div>

            <div className="flex items-center justify-center">
              <EnquiryForm className="w-full" compact />
            </div>
          </div>
        </div>
      </section>

      {/* CTA Banner */}
      <CTABanner />
    </>
  )
}
