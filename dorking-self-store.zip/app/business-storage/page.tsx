import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Check } from "lucide-react"
import CTABanner from "@/components/cta-banner"
import EnquiryForm from "@/components/enquiry-form"
import TestimonialSlider from "@/components/testimonial-slider"

export default function BusinessStoragePage() {
  return (
    <>
      {/* Hero Section */}
      <section className="bg-muted py-12 md:py-16">
        <div className="container">
          <div className="grid gap-8 lg:grid-cols-2">
            <div>
              <h1 className="mb-4 text-4xl font-bold tracking-tight md:text-5xl">
                Business Storage Solutions
                <span className="mt-2 block text-secondary">First Month Free</span>
              </h1>

              <p className="mb-6 text-lg text-muted-foreground">
                Flexible, secure storage solutions for businesses of all sizes. From document archiving to inventory
                management, we've got you covered.
              </p>

              <ul className="mb-6 space-y-2">
                <li className="flex items-center gap-2">
                  <Check className="h-5 w-5 text-secondary" />
                  <span>Secure, climate-controlled units</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="h-5 w-5 text-secondary" />
                  <span>Flexible contract terms</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="h-5 w-5 text-secondary" />
                  <span>24/7 access available</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="h-5 w-5 text-secondary" />
                  <span>Collection and delivery service</span>
                </li>
              </ul>

              <Button asChild size="lg">
                <a href="tel:01306880124">Call to Discuss: 01306 880124</a>
              </Button>
            </div>

            <div className="relative h-[300px] overflow-hidden rounded-lg md:h-[400px]">
              <Image
                src="/placeholder.svg?height=400&width=600"
                alt="Business storage solutions"
                fill
                className="object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Business Benefits */}
      <section className="py-12 md:py-16">
        <div className="container">
          <h2 className="mb-8 text-center text-3xl font-bold">Benefits for Your Business</h2>

          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            <div className="rounded-lg border bg-card p-6 shadow-sm">
              <h3 className="mb-4 text-xl font-bold">Inventory Management</h3>
              <p className="mb-4">
                Store excess inventory, seasonal stock, or promotional materials in a secure, accessible location.
              </p>
              <Image
                src="/placeholder.svg?height=200&width=300"
                alt="Inventory storage"
                width={300}
                height={200}
                className="rounded-lg"
              />
            </div>

            <div className="rounded-lg border bg-card p-6 shadow-sm">
              <h3 className="mb-4 text-xl font-bold">Document Archiving</h3>
              <p className="mb-4">
                Keep important documents and records safe in our climate-controlled units, protecting them from damage.
              </p>
              <Image
                src="/placeholder.svg?height=200&width=300"
                alt="Document archiving"
                width={300}
                height={200}
                className="rounded-lg"
              />
            </div>

            <div className="rounded-lg border bg-card p-6 shadow-sm">
              <h3 className="mb-4 text-xl font-bold">Equipment Storage</h3>
              <p className="mb-4">
                Store tools, equipment, or office furniture securely when not in use or during office relocations.
              </p>
              <Image
                src="/placeholder.svg?height=200&width=300"
                alt="Equipment storage"
                width={300}
                height={200}
                className="rounded-lg"
              />
            </div>

            <div className="rounded-lg border bg-card p-6 shadow-sm">
              <h3 className="mb-4 text-xl font-bold">Flexible Space</h3>
              <p className="mb-4">
                Scale your storage up or down as your business needs change, without long-term commitments.
              </p>
              <Image
                src="/placeholder.svg?height=200&width=300"
                alt="Flexible storage space"
                width={300}
                height={200}
                className="rounded-lg"
              />
            </div>

            <div className="rounded-lg border bg-card p-6 shadow-sm">
              <h3 className="mb-4 text-xl font-bold">Cost-Effective</h3>
              <p className="mb-4">Save on expensive office or retail space by storing non-essential items off-site.</p>
              <Image
                src="/placeholder.svg?height=200&width=300"
                alt="Cost-effective storage"
                width={300}
                height={200}
                className="rounded-lg"
              />
            </div>

            <div className="rounded-lg border bg-card p-6 shadow-sm">
              <h3 className="mb-4 text-xl font-bold">Convenient Access</h3>
              <p className="mb-4">
                Access your items when you need them with our flexible opening hours and optional 24/7 access.
              </p>
              <Image
                src="/placeholder.svg?height=200&width=300"
                alt="Convenient access"
                width={300}
                height={200}
                className="rounded-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Business Use Cases */}
      <section className="bg-muted py-12 md:py-16">
        <div className="container">
          <h2 className="mb-8 text-center text-3xl font-bold">Perfect For Your Business</h2>

          <div className="grid gap-8 md:grid-cols-2">
            <div className="flex flex-col gap-4">
              <div className="rounded-lg bg-card p-6 shadow-sm">
                <h3 className="mb-2 text-xl font-bold">Retail Businesses</h3>
                <p>Store seasonal inventory, display fixtures, or excess stock to keep your shop floor optimized.</p>
              </div>

              <div className="rounded-lg bg-card p-6 shadow-sm">
                <h3 className="mb-2 text-xl font-bold">E-commerce</h3>
                <p>Manage your inventory efficiently with secure storage and easy access for order fulfillment.</p>
              </div>

              <div className="rounded-lg bg-card p-6 shadow-sm">
                <h3 className="mb-2 text-xl font-bold">Tradespeople</h3>
                <p>Store tools, equipment, and materials securely between jobs or during quiet periods.</p>
              </div>
            </div>

            <div className="flex flex-col gap-4">
              <div className="rounded-lg bg-card p-6 shadow-sm">
                <h3 className="mb-2 text-xl font-bold">Office-Based Businesses</h3>
                <p>
                  Archive documents, store extra furniture, or keep equipment safe during office moves or renovations.
                </p>
              </div>

              <div className="rounded-lg bg-card p-6 shadow-sm">
                <h3 className="mb-2 text-xl font-bold">Startups</h3>
                <p>
                  Keep costs down with flexible storage that grows with your business, without long-term commitments.
                </p>
              </div>

              <div className="rounded-lg bg-card p-6 shadow-sm">
                <h3 className="mb-2 text-xl font-bold">Seasonal Businesses</h3>
                <p>Store equipment and inventory during off-seasons, ready for when you need it again.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-12 md:py-16">
        <div className="container">
          <h2 className="mb-8 text-center text-3xl font-bold">What Our Business Customers Say</h2>
          <TestimonialSlider className="mx-auto max-w-3xl" />
        </div>
      </section>

      {/* Enquiry Form */}
      <section className="bg-muted py-12 md:py-16">
        <div className="container">
          <div className="mx-auto max-w-2xl">
            <h2 className="mb-8 text-center text-3xl font-bold">Contact Us About Business Storage</h2>
            <EnquiryForm />
          </div>
        </div>
      </section>

      {/* CTA Banner */}
      <CTABanner
        title="Need Business Storage? Call Us Today!"
        subtitle="Speak to our team about your business storage requirements"
      />
    </>
  )
}
