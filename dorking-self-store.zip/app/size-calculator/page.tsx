import type { Metadata } from "next"
import SizeCalculator from "@/components/size-calculator"
import CTABanner from "@/components/cta-banner"

export const metadata: Metadata = {
  title: "Storage Unit Size Calculator | Dorking Self Store",
  description:
    "Use our interactive calculator to determine the perfect storage unit size for your needs. Get personalized recommendations based on your items.",
}

export default function SizeCalculatorPage() {
  return (
    <>
      {/* Hero Section */}
      <section className="bg-muted py-12 md:py-16">
        <div className="container">
          <div className="mx-auto max-w-3xl text-center">
            <h1 className="mb-4 text-4xl font-bold tracking-tight md:text-5xl">Storage Unit Size Calculator</h1>
            <p className="mb-6 text-lg text-muted-foreground">
              Not sure what size storage unit you need? Use our interactive calculator to get a personalized
              recommendation based on the items you plan to store.
            </p>
          </div>
        </div>
      </section>

      {/* Calculator Section */}
      <section className="py-12 md:py-16">
        <div className="container">
          <SizeCalculator />
        </div>
      </section>

      {/* CTA Banner */}
      <CTABanner
        title="Need Help Choosing a Storage Unit?"
        subtitle="Our friendly team is ready to assist you with personalized advice"
      />
    </>
  )
}
