import Image from "next/image"
import { Phone, Mail, MapPin, Clock } from "lucide-react"
import EnquiryForm from "@/components/enquiry-form"

export default function ContactPage() {
  return (
    <>
      {/* Hero Section */}
      <section className="bg-muted py-12 md:py-16">
        <div className="container">
          <div className="mx-auto max-w-3xl text-center">
            <h1 className="mb-4 text-4xl font-bold tracking-tight md:text-5xl">Contact Us</h1>

            <p className="mb-6 text-lg text-muted-foreground">
              Get in touch with our friendly team to discuss your storage needs or to arrange a visit to our facility.
            </p>
          </div>
        </div>
      </section>

      {/* Contact Details & Form */}
      <section className="py-12 md:py-16">
        <div className="container">
          <div className="grid gap-8 lg:grid-cols-2">
            <div>
              <h2 className="mb-6 text-3xl font-bold">Get in Touch</h2>

              <div className="mb-8 space-y-6">
                <div className="flex items-start gap-4">
                  <div className="rounded-full bg-primary/10 p-3 text-primary">
                    <Phone className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="mb-1 text-lg font-bold">Phone</h3>
                    <p className="mb-1">Call us for immediate assistance:</p>
                    <a href="tel:01306880124" className="text-lg font-medium text-primary hover:underline">
                      01306 880124
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="rounded-full bg-primary/10 p-3 text-primary">
                    <Mail className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="mb-1 text-lg font-bold">Email</h3>
                    <p className="mb-1">Send us an email:</p>
                    <a
                      href="mailto:info@dorkingselfstore.co.uk"
                      className="text-lg font-medium text-primary hover:underline"
                    >
                      info@dorkingselfstore.co.uk
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="rounded-full bg-primary/10 p-3 text-primary">
                    <MapPin className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="mb-1 text-lg font-bold">Address</h3>
                    <p className="mb-1">Visit our facility:</p>
                    <address className="not-italic">
                      <span className="text-lg font-medium">Dorking Self Store Ltd</span>
                      <br />
                      Dorking, Surrey
                      <br />
                      United Kingdom
                    </address>
                    <p className="mt-2">
                      <a
                        href="https://maps.google.com"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-primary hover:underline"
                      >
                        Get Directions
                      </a>
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="rounded-full bg-primary/10 p-3 text-primary">
                    <Clock className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="mb-1 text-lg font-bold">Opening Hours</h3>
                    <ul className="space-y-1">
                      <li className="flex justify-between">
                        <span>Monday - Friday</span>
                        <span>8am - 6pm</span>
                      </li>
                      <li className="flex justify-between">
                        <span>Saturday</span>
                        <span>9am - 4pm</span>
                      </li>
                      <li className="flex justify-between">
                        <span>Sunday</span>
                        <span>Closed</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>

              <div className="relative h-[300px] overflow-hidden rounded-lg md:h-[400px]">
                <Image
                  src="/placeholder.svg?height=400&width=600"
                  alt="Map of Dorking Self Store location"
                  fill
                  className="object-cover"
                />
              </div>
            </div>

            <div>
              <h2 className="mb-6 text-3xl font-bold">Send Us a Message</h2>
              <EnquiryForm />
            </div>
          </div>
        </div>
      </section>
    </>
  )
}
