import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import CTABanner from "@/components/cta-banner"
import EnquiryForm from "@/components/enquiry-form"

export default function FAQsPage() {
  return (
    <>
      {/* Hero Section */}
      <section className="bg-muted py-12 md:py-16">
        <div className="container">
          <div className="mx-auto max-w-3xl text-center">
            <h1 className="mb-4 text-4xl font-bold tracking-tight md:text-5xl">Frequently Asked Questions</h1>

            <p className="mb-6 text-lg text-muted-foreground">
              Find answers to common questions about our storage services. If you can't find what you're looking for,
              please don't hesitate to contact us.
            </p>
          </div>
        </div>
      </section>

      {/* FAQs Section */}
      <section className="py-12 md:py-16">
        <div className="container">
          <div className="mx-auto max-w-3xl">
            <Accordion type="single" collapsible className="w-full">
              <AccordionItem value="item-1">
                <AccordionTrigger>What are your access hours?</AccordionTrigger>
                <AccordionContent>
                  <p>
                    Our standard access hours are Monday to Friday from 8am to 6pm, and Saturday from 9am to 4pm. We're
                    closed on Sundays and Bank Holidays. If you need access outside these hours, please contact us to
                    discuss our 24/7 access options.
                  </p>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-2">
                <AccordionTrigger>Do I need insurance for my stored items?</AccordionTrigger>
                <AccordionContent>
                  <p>
                    Yes, all items stored at our facility must be insured. We offer comprehensive insurance options that
                    can be added to your storage agreement, or you can provide proof of your own insurance coverage. Our
                    team can advise on the best option for your needs.
                  </p>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-3">
                <AccordionTrigger>How secure is your facility?</AccordionTrigger>
                <AccordionContent>
                  <p>
                    Security is our top priority. Our facility features 24/7 CCTV monitoring, individual unit alarms,
                    secure access control, perimeter fencing, and on-site staff during business hours. Each storage unit
                    has its own lock, and only you have the key.
                  </p>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-4">
                <AccordionTrigger>What size storage unit do I need?</AccordionTrigger>
                <AccordionContent>
                  <p>The size you need depends on what you're storing. As a rough guide:</p>
                  <ul className="mt-2 list-disc pl-6">
                    <li>25 sq ft (5ft × 5ft): Small furniture items, boxes, seasonal items</li>
                    <li>50 sq ft (10ft × 5ft): Contents of a one-bedroom flat</li>
                    <li>100 sq ft (10ft × 10ft): Contents of a three-bedroom house</li>
                    <li>150 sq ft (15ft × 10ft): Contents of a four-bedroom house</li>
                    <li>200 sq ft (20ft × 10ft): Full house contents, large furniture items</li>
                  </ul>
                  <p className="mt-2">
                    Our team can help you determine the right size for your needs. We also offer a{" "}
                    <Link href="/size-calculator" className="text-primary hover:underline">
                      size calculator
                    </Link>{" "}
                    on our website.
                  </p>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-5">
                <AccordionTrigger>How does the "First Month Free" offer work?</AccordionTrigger>
                <AccordionContent>
                  <p>
                    Our First Month Free offer is available to new customers who sign up for a minimum storage period of
                    two months. The first month's rent is completely free, and you'll only start paying from the second
                    month onwards. There are no hidden fees or catches - it's our way of welcoming you to Dorking Self
                    Store.
                  </p>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-6">
                <AccordionTrigger>Do you offer a collection and delivery service?</AccordionTrigger>
                <AccordionContent>
                  <p>
                    Yes, we offer a convenient collection and delivery service for customers who don't have their own
                    transport or prefer the convenience. Our team will collect your items from your home or business,
                    transport them safely to our facility, and deliver them back to you when you need them. Please
                    contact us for pricing and to arrange this service.
                  </p>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-7">
                <AccordionTrigger>What is the minimum storage period?</AccordionTrigger>
                <AccordionContent>
                  <p>
                    Our minimum storage period is one month. However, to take advantage of our First Month Free offer,
                    you'll need to commit to a minimum of two months (with the first month being free).
                  </p>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-8">
                <AccordionTrigger>Are your units climate-controlled?</AccordionTrigger>
                <AccordionContent>
                  <p>
                    Yes, all our storage units are climate-controlled to maintain a consistent temperature and humidity
                    level. This helps protect sensitive items such as furniture, electronics, documents, and clothing
                    from damage caused by extreme temperature changes, humidity, or damp.
                  </p>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-9">
                <AccordionTrigger>What payment methods do you accept?</AccordionTrigger>
                <AccordionContent>
                  <p>
                    We accept various payment methods including credit/debit cards, direct debit, bank transfers, and
                    cash. Most customers prefer to set up a monthly direct debit for convenience. Please note that we
                    require payment in advance for each storage period.
                  </p>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-10">
                <AccordionTrigger>Can I access my storage unit at any time?</AccordionTrigger>
                <AccordionContent>
                  <p>
                    Our standard access hours are Monday to Friday from 8am to 6pm, and Saturday from 9am to 4pm.
                    However, we understand that some customers need more flexible access. We offer 24/7 access options
                    for an additional fee. Please contact us to discuss your specific requirements.
                  </p>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-11">
                <AccordionTrigger>What items are prohibited in storage?</AccordionTrigger>
                <AccordionContent>
                  <p>For safety and legal reasons, certain items cannot be stored in our facility. These include:</p>
                  <ul className="mt-2 list-disc pl-6">
                    <li>Flammable, explosive, or hazardous materials</li>
                    <li>Perishable items or food products</li>
                    <li>Live plants or animals</li>
                    <li>Illegal items or substances</li>
                    <li>Firearms, weapons, or ammunition</li>
                    <li>Cash or securities</li>
                  </ul>
                  <p className="mt-2">If you're unsure about any items, please contact us for clarification.</p>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-12">
                <AccordionTrigger>Do you sell packing materials?</AccordionTrigger>
                <AccordionContent>
                  <p>
                    Yes, we sell a range of packing materials to help you store your items safely. Our stock includes
                    boxes in various sizes, bubble wrap, packing tape, protective covers, and more. These are available
                    for purchase at our facility during business hours.
                  </p>
                </AccordionContent>
              </AccordionItem>
            </Accordion>

            <div className="mt-8 text-center">
              <p className="mb-4">Can't find the answer you're looking for?</p>

              <div className="flex flex-col justify-center gap-4 sm:flex-row">
                <Button asChild>
                  <a href="tel:01306880124">Call Us: 01306 880124</a>
                </Button>

                <Button asChild variant="outline">
                  <Link href="/contact">Contact Form</Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Enquiry Form */}
      <section className="bg-muted py-12 md:py-16">
        <div className="container">
          <div className="mx-auto max-w-2xl">
            <h2 className="mb-8 text-center text-3xl font-bold">Get in Touch</h2>
            <EnquiryForm />
          </div>
        </div>
      </section>

      {/* CTA Banner */}
      <CTABanner />
    </>
  )
}
