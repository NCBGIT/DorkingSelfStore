import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Phone, MapPin } from "lucide-react"
import EnquiryForm from "@/components/enquiry-form"
import TestimonialSlider from "@/components/testimonial-slider"
import USPSection from "@/components/usp-section"
import CTABanner from "@/components/cta-banner"
import StorageUnitCard from "@/components/storage-unit-card"

export default function Home() {
  return (
    <>
      {/* Hero Section */}
      <section className="hero-pattern py-12 md:py-20 lg:py-24">
        <div className="container">
          <div className="grid gap-8 lg:grid-cols-2 lg:gap-12">
            <div className="flex flex-col justify-center">
              <h1 className="mb-4 text-4xl font-bold tracking-tight md:text-5xl lg:text-6xl">
                Secure, Heated & Local Storage in Dorking
                <span className="mt-2 block text-secondary">First Month Free</span>
              </h1>

              <p className="mb-6 text-xl text-muted-foreground">
                Flexible units for homeowners & businesses. No VAT. Call us now.
              </p>

              <div className="flex flex-col gap-4 sm:flex-row">
                <Button asChild size="lg" className="gap-2">
                  <a href="tel:01306880124">
                    <Phone className="h-5 w-5" />
                    <span>Call Now</span>
                  </a>
                </Button>

                <Button asChild variant="outline" size="lg">
                  <Link href="/contact">Get a Quote</Link>
                </Button>
              </div>
            </div>

            <div className="flex items-center justify-center">
              <EnquiryForm className="w-full max-w-md" compact />
            </div>
          </div>
        </div>
      </section>

      {/* USP Section */}
      <USPSection />

      {/* Testimonials Section */}
      <section className="py-12 md:py-16">
        <div className="container">
          <TestimonialSlider className="mx-auto max-w-3xl" />
        </div>
      </section>

      {/* Storage Units Preview */}
      <section className="bg-muted py-12 md:py-16">
        <div className="container">
          <h2 className="mb-8 text-center text-3xl font-bold">Our Storage Units</h2>

          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            <StorageUnitCard
              size="Small Unit"
              dimensions="25 sq ft (5ft × 5ft)"
              price="£85"
              description="Perfect for small household items, seasonal decorations, or business documents."
              imageSrc="/placeholder.svg?height=300&width=400"
            />

            <StorageUnitCard
              size="Medium Unit"
              dimensions="50 sq ft (10ft × 5ft)"
              price="£157"
              description="Ideal for the contents of a one-bedroom flat or small office equipment."
              imageSrc="/placeholder.svg?height=300&width=400"
              popular
            />

            <StorageUnitCard
              size="Large Unit"
              dimensions="100 sq ft (10ft × 10ft)"
              price="£295"
              description="Suitable for the contents of a three-bedroom house or larger business inventory."
              imageSrc="/placeholder.svg?height=300&width=400"
            />
          </div>

          <div className="mt-8 text-center">
            <Button asChild size="lg">
              <Link href="/storage-units">View All Storage Units</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Map Section */}
      <section className="py-12 md:py-16">
        <div className="container">
          <div className="grid gap-8 lg:grid-cols-2">
            <div>
              <h2 className="mb-4 text-3xl font-bold">Find Us</h2>
              <p className="mb-6">
                Conveniently located in Dorking, Surrey, our storage facility is easily accessible from surrounding
                areas including Reigate, Leatherhead, and Horsham.
              </p>

              <div className="mb-6 flex items-start gap-2">
                <MapPin className="mt-1 h-5 w-5 flex-shrink-0 text-primary" />
                <address className="not-italic">
                  <strong>Dorking Self Store Ltd</strong>
                  <br />
                  Dorking, Surrey
                  <br />
                  United Kingdom
                </address>
              </div>

              <div className="mb-6">
                <h3 className="mb-2 text-xl font-bold">Opening Hours</h3>
                <ul className="space-y-1">
                  <li className="flex justify-between">
                    <span>Monday - Friday</span>
                    <span>8am - 6pm</span>
                  </li>
                  <li className="flex justify-between">
                    <span>Saturday</span>
                    <span>9am - 4pm</span>
                  </li>
                  <li className="flex justify-between">
                    <span>Sunday</span>
                    <span>Closed</span>
                  </li>
                </ul>
              </div>

              <Button asChild className="gap-2">
                <a href="https://maps.google.com" target="_blank" rel="noopener noreferrer">
                  Get Directions
                </a>
              </Button>
            </div>

            <div className="relative h-[300px] overflow-hidden rounded-lg md:h-[400px]">
              <Image
                src="/placeholder.svg?height=400&width=600"
                alt="Map of Dorking Self Store location"
                fill
                className="object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* CTA Banner */}
      <CTABanner />
    </>
  )
}
