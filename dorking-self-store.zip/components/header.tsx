"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Phone, Menu, X } from "lucide-react"
import { cn } from "@/lib/utils"

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen)
  }

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-2">
          <Link href="/" className="flex items-center space-x-2">
            <span className="text-xl font-bold text-primary">Dorking Self Store</span>
          </Link>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-6">
          <Link href="/" className="text-sm font-medium hover:text-primary">
            Home
          </Link>
          <Link href="/storage-units" className="text-sm font-medium hover:text-primary">
            Storage Units
          </Link>
          <Link href="/business-storage" className="text-sm font-medium hover:text-primary">
            Business Storage
          </Link>
          <Link href="/domestic-storage" className="text-sm font-medium hover:text-primary">
            Domestic Storage
          </Link>
          <Link href="/why-choose-us" className="text-sm font-medium hover:text-primary">
            Why Choose Us
          </Link>
          <Link href="/size-calculator" className="text-sm font-medium hover:text-primary">
            Size Calculator
          </Link>
          <Link href="/compare-units" className="text-sm font-medium hover:text-primary">
            Compare Units
          </Link>
          <Link href="/faqs" className="text-sm font-medium hover:text-primary">
            FAQs
          </Link>
          <Link href="/contact" className="text-sm font-medium hover:text-primary">
            Contact
          </Link>
        </nav>

        {/* Call Now Button */}
        <div className="hidden md:flex">
          <Button asChild className="gap-2">
            <a href="tel:01306880124">
              <Phone className="h-4 w-4" />
              <span>Call Now: 01306 880124</span>
            </a>
          </Button>
        </div>

        {/* Mobile Menu Button */}
        <div className="flex md:hidden">
          <Button variant="ghost" size="icon" onClick={toggleMenu} aria-label="Toggle Menu">
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </Button>
        </div>
      </div>

      {/* Mobile Navigation */}
      <div
        className={cn(
          "fixed inset-0 top-16 z-50 grid h-[calc(100vh-4rem)] grid-flow-row auto-rows-max overflow-auto p-6 pb-32 shadow-md animate-in md:hidden bg-background",
          isMenuOpen ? "slide-in-from-top-80" : "hidden",
        )}
      >
        <div className="relative z-20 grid gap-6 rounded-md p-4">
          <Link href="/" className="flex items-center space-x-2" onClick={toggleMenu}>
            <span className="font-medium">Home</span>
          </Link>
          <Link href="/storage-units" className="flex items-center space-x-2" onClick={toggleMenu}>
            <span className="font-medium">Storage Units</span>
          </Link>
          <Link href="/business-storage" className="flex items-center space-x-2" onClick={toggleMenu}>
            <span className="font-medium">Business Storage</span>
          </Link>
          <Link href="/domestic-storage" className="flex items-center space-x-2" onClick={toggleMenu}>
            <span className="font-medium">Domestic Storage</span>
          </Link>
          <Link href="/why-choose-us" className="flex items-center space-x-2" onClick={toggleMenu}>
            <span className="font-medium">Why Choose Us</span>
          </Link>
          <Link href="/size-calculator" className="flex items-center space-x-2" onClick={toggleMenu}>
            <span className="font-medium">Size Calculator</span>
          </Link>
          <Link href="/compare-units" className="flex items-center space-x-2" onClick={toggleMenu}>
            <span className="font-medium">Compare Units</span>
          </Link>
          <Link href="/faqs" className="flex items-center space-x-2" onClick={toggleMenu}>
            <span className="font-medium">FAQs</span>
          </Link>
          <Link href="/contact" className="flex items-center space-x-2" onClick={toggleMenu}>
            <span className="font-medium">Contact</span>
          </Link>
          <Button asChild className="w-full gap-2">
            <a href="tel:01306880124">
              <Phone className="h-4 w-4" />
              <span>Call Now: 01306 880124</span>
            </a>
          </Button>
        </div>
      </div>
    </header>
  )
}
