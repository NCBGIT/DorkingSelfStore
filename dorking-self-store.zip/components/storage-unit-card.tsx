import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

interface StorageUnitCardProps {
  size: string
  dimensions: string
  price: string
  description: string
  imageSrc: string
  popular?: boolean
  className?: string
}

export default function StorageUnitCard({
  size,
  dimensions,
  price,
  description,
  imageSrc,
  popular = false,
  className,
}: StorageUnitCardProps) {
  return (
    <div
      className={cn(
        "relative overflow-hidden rounded-lg border bg-card text-card-foreground shadow transition-all hover:shadow-lg",
        popular && "ring-2 ring-secondary",
        className,
      )}
    >
      {popular && (
        <div className="absolute right-0 top-0 bg-secondary px-3 py-1 text-xs font-medium text-secondary-foreground">
          Popular Choice
        </div>
      )}

      <div className="relative h-48 w-full overflow-hidden">
        <Image src={imageSrc || "/placeholder.svg"} alt={`${size} storage unit`} fill className="object-cover" />
      </div>

      <div className="p-6">
        <h3 className="text-xl font-bold">{size}</h3>
        <p className="text-sm text-muted-foreground">{dimensions}</p>

        {/* Pricing removed */}

        <p className="mb-6 text-sm">{description}</p>

        <div className="flex flex-col gap-2 sm:flex-row">
          <Button asChild className="w-full">
            <a href="tel:01306880124">Call to Reserve</a>
          </Button>

          <Button asChild variant="outline" className="w-full">
            <Link href="/contact">Get a Quote</Link>
          </Button>
        </div>
      </div>
    </div>
  )
}
