import type React from "react"
import { Lock, Truck, Banknote, Home, Briefcase, Award } from "lucide-react"

interface USPItemProps {
  icon: React.ReactNode
  title: string
  description: string
}

function USPItem({ icon, title, description }: USPItemProps) {
  return (
    <div className="flex flex-col items-center text-center">
      <div className="mb-4 rounded-full bg-primary/10 p-3 text-primary">{icon}</div>
      <h3 className="mb-2 text-lg font-bold">{title}</h3>
      <p className="text-sm text-muted-foreground">{description}</p>
    </div>
  )
}

export default function USPSection() {
  return (
    <section className="py-12 md:py-16">
      <div className="container">
        <h2 className="mb-8 text-center text-3xl font-bold">Why Choose Dorking Self Store?</h2>

        <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
          <USPItem
            icon={<Lock className="h-6 w-6" />}
            title="Secure Climate-Controlled Units"
            description="Our facility features 24/7 security and climate-controlled units to keep your belongings safe and in perfect condition."
          />

          <USPItem
            icon={<Truck className="h-6 w-6" />}
            title="Collection & Delivery Service"
            description="We offer a convenient collection and delivery service to make your storage experience hassle-free."
          />

          <USPItem
            icon={<Banknote className="h-6 w-6" />}
            title="First Month Free Offer"
            description="Take advantage of our special offer: get your first month of storage absolutely free!"
          />

          <USPItem
            icon={<Home className="h-6 w-6" />}
            title="Perfect for Homeowners"
            description="Ideal for house moves, renovations, or simply creating more space in your home."
          />

          <USPItem
            icon={<Briefcase className="h-6 w-6" />}
            title="Business-Friendly Solutions"
            description="Flexible storage options for inventory, documents, equipment, and more for businesses of all sizes."
          />

          <USPItem
            icon={<Award className="h-6 w-6" />}
            title="Local & Trusted Since 2001"
            description="A family-run business with deep roots in the Dorking community, providing personal service you can trust."
          />
        </div>
      </div>
    </section>
  )
}
