import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Phone } from "lucide-react"
import { cn } from "@/lib/utils"

interface CTABannerProps {
  title?: string
  subtitle?: string
  className?: string
}

export default function CTABanner({
  title = "Need Storage Space? Call Us Today!",
  subtitle = "Speak to our friendly team for advice and to claim your first month free",
  className,
}: CTABannerProps) {
  return (
    <section className={cn("bg-secondary py-10 text-secondary-foreground", className)}>
      <div className="container">
        <div className="flex flex-col items-center justify-between gap-6 text-center md:flex-row md:text-left">
          <div>
            <h2 className="text-2xl font-bold md:text-3xl">{title}</h2>
            <p className="mt-2">{subtitle}</p>
          </div>

          <div className="flex flex-col gap-4 sm:flex-row">
            <Button asChild size="lg" className="gap-2">
              <a href="tel:01306880124">
                <Phone className="h-5 w-5" />
                <span>Call: 01306 880124</span>
              </a>
            </Button>

            <Button asChild variant="outline" size="lg">
              <Link href="/contact">Get a Quote</Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
