import type { SelectedItems } from "./storage-items"

// Calculate total cubic feet based on selected items
export function calculateTotalSpace(selectedItems: SelectedItems): number {
  let totalSpace = 0

  // Import here to avoid circular dependency
  const { storageItems } = require("./storage-items")

  Object.entries(selectedItems).forEach(([itemId, quantity]) => {
    const item = storageItems.find((item) => item.id === itemId)
    if (item && quantity > 0) {
      totalSpace += item.cubicFeet * quantity
    }
  })

  return totalSpace
}

// Get recommended unit size based on total cubic feet
export function getRecommendedUnit(totalCubicFeet: number): string | null {
  if (totalCubicFeet === 0) return null

  // Unit size thresholds in cubic feet
  // These are approximate conversions from square feet to cubic feet
  // assuming an 8-foot ceiling height
  if (totalCubicFeet <= 200) return "Small Unit" // 25 sq ft × 8ft height
  if (totalCubicFeet <= 400) return "Medium Unit" // 50 sq ft × 8ft height
  if (totalCubicFeet <= 800) return "Large Unit" // 100 sq ft × 8ft height
  if (totalCubicFeet <= 1200) return "Extra Large Unit" // 150 sq ft × 8ft height
  return "Garage Unit" // 200 sq ft × 8ft height
}
