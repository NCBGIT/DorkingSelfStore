import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Phone, ArrowRight } from "lucide-react"
import { type SelectedItems, storageItems } from "./storage-items"

interface ResultsDisplayProps {
  totalCubicFeet: number
  recommendedUnit: string | null
  selectedItems: SelectedItems
}

export default function ResultsDisplay({ totalCubicFeet, recommendedUnit, selectedItems }: ResultsDisplayProps) {
  // Get unit details based on recommendation
  const getUnitDetails = () => {
    if (!recommendedUnit) return null

    const unitDetails = {
      "Small Unit": {
        size: "25 sq ft (5ft × 5ft)",
        price: "£85",
        image: "/placeholder.svg?height=200&width=200",
      },
      "Medium Unit": {
        size: "50 sq ft (10ft × 5ft)",
        price: "£157",
        image: "/placeholder.svg?height=200&width=200",
      },
      "Large Unit": {
        size: "100 sq ft (10ft × 10ft)",
        price: "£295",
        image: "/placeholder.svg?height=200&width=200",
      },
      "Extra Large Unit": {
        size: "150 sq ft (15ft × 10ft)",
        price: "£425",
        image: "/placeholder.svg?height=200&width=200",
      },
      "Garage Unit": {
        size: "200 sq ft (20ft × 10ft)",
        price: "£550",
        image: "/placeholder.svg?height=200&width=200",
      },
    }[recommendedUnit]

    return unitDetails
  }

  const unitDetails = getUnitDetails()

  // Count total items selected
  const totalItems = Object.values(selectedItems).reduce((sum, quantity) => sum + quantity, 0)

  // Get list of selected items with quantities
  const getSelectedItemsList = () => {
    const selectedItemsList = Object.entries(selectedItems)
      .filter(([_, quantity]) => quantity > 0)
      .map(([itemId, quantity]) => {
        const item = storageItems.find((i) => i.id === itemId)
        return { ...item, quantity }
      })

    return selectedItemsList
  }

  const selectedItemsList = getSelectedItemsList()

  return (
    <div className="rounded-lg bg-muted p-4">
      {totalCubicFeet > 0 ? (
        <>
          <div className="mb-4 text-center">
            <h3 className="text-lg font-bold">Recommended Storage Unit</h3>
            {recommendedUnit ? (
              <div className="mt-4">
                <div className="mb-3 flex justify-center">
                  <div className="relative h-32 w-32 overflow-hidden rounded-lg">
                    <Image
                      src={unitDetails?.image || "/placeholder.svg?height=200&width=200"}
                      alt={recommendedUnit}
                      fill
                      className="object-cover"
                    />
                  </div>
                </div>
                <h4 className="text-xl font-bold text-primary">{recommendedUnit}</h4>
                <p className="text-sm">{unitDetails?.size}</p>
                <p className="mt-1 text-lg font-bold">{unitDetails?.price}/month</p>
                <p className="mt-1 text-xs text-muted-foreground">First month free for new customers!</p>

                <div className="mt-3">
                  <Link
                    href="/compare-units"
                    className="inline-flex items-center gap-1 text-sm text-primary hover:underline"
                  >
                    Compare with other units
                    <ArrowRight className="h-3 w-3" />
                  </Link>
                </div>
              </div>
            ) : (
              <p>Add more items to get a recommendation</p>
            )}
          </div>

          <div className="mb-4">
            <h4 className="mb-2 text-sm font-medium">Selected Items ({totalItems})</h4>
            <div className="max-h-32 overflow-y-auto rounded-md bg-background p-2 text-xs">
              {selectedItemsList.length > 0 ? (
                <ul className="space-y-1">
                  {selectedItemsList.map((item) => (
                    <li key={item?.id} className="flex justify-between">
                      <span>
                        {item?.name} × {item?.quantity}
                      </span>
                      <span>{((item?.cubicFeet || 0) * (item?.quantity || 0)).toFixed(1)} ft³</span>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-center text-muted-foreground">No items selected</p>
              )}
            </div>
          </div>

          <div className="space-y-2">
            <Button asChild className="w-full gap-2">
              <a href="tel:01306880124">
                <Phone className="h-4 w-4" />
                <span>Call to Reserve</span>
              </a>
            </Button>
            <Button asChild variant="outline" className="w-full">
              <Link href="/contact">Get a Quote</Link>
            </Button>
          </div>
        </>
      ) : (
        <div className="py-8 text-center">
          <h3 className="mb-2 text-lg font-bold">Your Results</h3>
          <p className="mb-4 text-muted-foreground">Select items to calculate your storage needs</p>
          <Image
            src="/placeholder.svg?height=150&width=150"
            alt="Storage calculator"
            width={150}
            height={150}
            className="mx-auto"
          />
        </div>
      )}
    </div>
  )
}
