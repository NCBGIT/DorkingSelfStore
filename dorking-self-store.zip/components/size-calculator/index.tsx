"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Phone } from "lucide-react"
import ItemSelector from "./item-selector"
import ResultsDisplay from "./results-display"
import { calculateTotalSpace, getRecommendedUnit } from "./calculator-utils"
import { type StorageItem, type SelectedItems, storageItems } from "./storage-items"

export default function SizeCalculator() {
  const [selectedItems, setSelectedItems] = useState<SelectedItems>({})
  const [totalCubicFeet, setTotalCubicFeet] = useState(0)
  const [recommendedUnit, setRecommendedUnit] = useState<string | null>(null)
  const [activeTab, setActiveTab] = useState("bedroom")

  // Calculate total space and recommended unit when selected items change
  useEffect(() => {
    const total = calculateTotalSpace(selectedItems)
    setTotalCubicFeet(total)
    setRecommendedUnit(getRecommendedUnit(total))
  }, [selectedItems])

  // Handle item selection
  const handleItemChange = (itemId: string, quantity: number) => {
    setSelectedItems((prev) => ({
      ...prev,
      [itemId]: quantity,
    }))
  }

  // Reset all selections
  const handleReset = () => {
    setSelectedItems({})
  }

  // Group items by category
  const itemsByCategory: Record<string, StorageItem[]> = storageItems.reduce(
    (acc, item) => {
      if (!acc[item.category]) {
        acc[item.category] = []
      }
      acc[item.category].push(item)
      return acc
    },
    {} as Record<string, StorageItem[]>,
  )

  // Get categories
  const categories = Object.keys(itemsByCategory)

  return (
    <div className="mx-auto max-w-4xl">
      <Card>
        <CardContent className="p-6">
          <div className="mb-8 grid gap-6 md:grid-cols-3">
            <div className="col-span-2">
              <h2 className="mb-4 text-2xl font-bold">Select Your Items</h2>
              <p className="mb-6 text-muted-foreground">
                Choose the items you plan to store by selecting quantities for each item. The calculator will
                automatically estimate the space needed.
              </p>
            </div>
            <div className="flex flex-col items-center justify-center rounded-lg bg-muted p-4 text-center">
              <p className="mb-2 text-sm text-muted-foreground">Need help?</p>
              <Button asChild className="w-full gap-2">
                <a href="tel:01306880124">
                  <Phone className="h-4 w-4" />
                  <span>Call: 01306 880124</span>
                </a>
              </Button>
            </div>
          </div>

          <div className="grid gap-8 md:grid-cols-5">
            {/* Item Selection */}
            <div className="md:col-span-3">
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="mb-4 w-full grid grid-cols-2 md:grid-cols-4">
                  {categories.map((category) => (
                    <TabsTrigger key={category} value={category} className="capitalize">
                      {category}
                    </TabsTrigger>
                  ))}
                </TabsList>

                {categories.map((category) => (
                  <TabsContent key={category} value={category} className="mt-0">
                    <ItemSelector
                      items={itemsByCategory[category]}
                      selectedItems={selectedItems}
                      onItemChange={handleItemChange}
                    />
                  </TabsContent>
                ))}

                <div className="mt-6 flex justify-between">
                  <Button variant="outline" onClick={handleReset}>
                    Reset Selections
                  </Button>
                  <div className="text-right">
                    <p className="text-sm text-muted-foreground">Total Volume</p>
                    <p className="text-2xl font-bold">{totalCubicFeet.toFixed(1)} ft³</p>
                  </div>
                </div>
              </Tabs>
            </div>

            {/* Results Display */}
            <div className="md:col-span-2">
              <ResultsDisplay
                totalCubicFeet={totalCubicFeet}
                recommendedUnit={recommendedUnit}
                selectedItems={selectedItems}
              />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
