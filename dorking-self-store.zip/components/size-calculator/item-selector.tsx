"use client"

import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import type { StorageItem, SelectedItems } from "./storage-items"

interface ItemSelectorProps {
  items: StorageItem[]
  selectedItems: SelectedItems
  onItemChange: (itemId: string, quantity: number) => void
}

export default function ItemSelector({ items, selectedItems, onItemChange }: ItemSelectorProps) {
  return (
    <div className="grid gap-4 sm:grid-cols-2">
      {items.map((item) => (
        <div key={item.id} className="flex items-center justify-between rounded-lg border p-3">
          <div className="flex-1">
            <Label htmlFor={item.id} className="font-medium">
              {item.name}
            </Label>
            <p className="text-xs text-muted-foreground">{item.cubicFeet} ft³</p>
          </div>
          <div className="w-20">
            <Input
              id={item.id}
              type="number"
              min="0"
              max="99"
              value={selectedItems[item.id] || 0}
              onChange={(e) => onItemChange(item.id, Number.parseInt(e.target.value) || 0)}
              className="text-center"
            />
          </div>
        </div>
      ))}
    </div>
  )
}
