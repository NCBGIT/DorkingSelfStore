// Define the structure for storage items
export interface StorageItem {
  id: string
  name: string
  category: string
  cubicFeet: number
}

// Define the structure for selected items (id -> quantity)
export interface SelectedItems {
  [key: string]: number
}

// List of common storage items with their approximate cubic feet
export const storageItems: StorageItem[] = [
  // Bedroom Items
  { id: "bed_king", name: "King Size Bed", category: "bedroom", cubicFeet: 70 },
  { id: "bed_queen", name: "Queen Size Bed", category: "bedroom", cubicFeet: 60 },
  { id: "bed_double", name: "Double Bed", category: "bedroom", cubicFeet: 50 },
  { id: "bed_single", name: "Single Bed", category: "bedroom", cubicFeet: 40 },
  { id: "mattress_king", name: "King Mattress", category: "bedroom", cubicFeet: 20 },
  { id: "mattress_queen", name: "Queen Mattress", category: "bedroom", cubicFeet: 18 },
  { id: "mattress_double", name: "Double Mattress", category: "bedroom", cubicFeet: 15 },
  { id: "mattress_single", name: "Single Mattress", category: "bedroom", cubicFeet: 12 },
  { id: "wardrobe", name: "Wardrobe", category: "bedroom", cubicFeet: 50 },
  { id: "chest_drawers", name: "Chest of Drawers", category: "bedroom", cubicFeet: 30 },
  { id: "bedside_table", name: "Bedside Table", category: "bedroom", cubicFeet: 5 },
  { id: "dressing_table", name: "Dressing Table", category: "bedroom", cubicFeet: 25 },

  // Living Room Items
  { id: "sofa_3seater", name: "3-Seater Sofa", category: "living", cubicFeet: 60 },
  { id: "sofa_2seater", name: "2-Seater Sofa", category: "living", cubicFeet: 45 },
  { id: "armchair", name: "Armchair", category: "living", cubicFeet: 20 },
  { id: "coffee_table", name: "Coffee Table", category: "living", cubicFeet: 15 },
  { id: "tv_stand", name: "TV Stand", category: "living", cubicFeet: 20 },
  { id: "bookcase", name: "Bookcase", category: "living", cubicFeet: 30 },
  { id: "sideboard", name: "Sideboard", category: "living", cubicFeet: 35 },
  { id: "tv_large", name: "Large TV (boxed)", category: "living", cubicFeet: 10 },
  { id: "lamp_floor", name: "Floor Lamp", category: "living", cubicFeet: 5 },
  { id: "rug", name: "Rug (rolled)", category: "living", cubicFeet: 3 },

  // Dining Room Items
  { id: "dining_table", name: "Dining Table", category: "dining", cubicFeet: 40 },
  { id: "dining_chair", name: "Dining Chair", category: "dining", cubicFeet: 5 },
  { id: "china_cabinet", name: "China Cabinet", category: "dining", cubicFeet: 45 },
  { id: "buffet", name: "Buffet/Sideboard", category: "dining", cubicFeet: 30 },
  { id: "bar_cart", name: "Bar Cart", category: "dining", cubicFeet: 8 },

  // Kitchen Items
  { id: "fridge", name: "Refrigerator", category: "kitchen", cubicFeet: 40 },
  { id: "freezer", name: "Freezer", category: "kitchen", cubicFeet: 30 },
  { id: "dishwasher", name: "Dishwasher", category: "kitchen", cubicFeet: 20 },
  { id: "microwave", name: "Microwave", category: "kitchen", cubicFeet: 5 },
  { id: "kitchen_box", name: "Box of Kitchenware", category: "kitchen", cubicFeet: 3 },
  { id: "small_appliance", name: "Small Appliance", category: "kitchen", cubicFeet: 2 },

  // Office Items
  { id: "desk", name: "Desk", category: "office", cubicFeet: 30 },
  { id: "office_chair", name: "Office Chair", category: "office", cubicFeet: 10 },
  { id: "filing_cabinet", name: "Filing Cabinet", category: "office", cubicFeet: 15 },
  { id: "computer", name: "Computer (boxed)", category: "office", cubicFeet: 4 },
  { id: "printer", name: "Printer", category: "office", cubicFeet: 3 },
  { id: "document_box", name: "Box of Documents", category: "office", cubicFeet: 2 },

  // Boxes & Containers
  { id: "box_small", name: "Small Box", category: "boxes", cubicFeet: 1.5 },
  { id: "box_medium", name: "Medium Box", category: "boxes", cubicFeet: 3 },
  { id: "box_large", name: "Large Box", category: "boxes", cubicFeet: 4.5 },
  { id: "wardrobe_box", name: "Wardrobe Box", category: "boxes", cubicFeet: 10 },
  { id: "plastic_bin", name: "Plastic Storage Bin", category: "boxes", cubicFeet: 4 },
  { id: "suitcase", name: "Suitcase", category: "boxes", cubicFeet: 5 },

  // Miscellaneous Items
  { id: "bicycle", name: "Bicycle", category: "misc", cubicFeet: 10 },
  { id: "lawn_mower", name: "Lawn Mower", category: "misc", cubicFeet: 15 },
  { id: "bbq_grill", name: "BBQ Grill", category: "misc", cubicFeet: 20 },
  { id: "garden_furniture", name: "Garden Furniture Set", category: "misc", cubicFeet: 40 },
  { id: "tools", name: "Box of Tools", category: "misc", cubicFeet: 3 },
  { id: "christmas_deco", name: "Christmas Decorations", category: "misc", cubicFeet: 8 },
  { id: "sports_equipment", name: "Sports Equipment", category: "misc", cubicFeet: 10 },
  { id: "vacuum", name: "Vacuum Cleaner", category: "misc", cubicFeet: 5 },
  { id: "ironing_board", name: "Ironing Board", category: "misc", cubicFeet: 4 },
  { id: "guitar", name: "Guitar (cased)", category: "misc", cubicFeet: 3 },
]
