import Link from "next/link"
import { Phone, Mail, MapPin, Clock } from "lucide-react"

export default function Footer() {
  const currentYear = new Date().getFullYear()

  return (
    <footer className="bg-primary text-primary-foreground">
      <div className="container py-12 md:py-16">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-4">
          <div>
            <h3 className="mb-4 text-lg font-bold">Dorking Self Store</h3>
            <p className="mb-4 text-sm">
              Secure, climate-controlled storage units for homeowners and businesses in Dorking, Surrey.
            </p>
            <div className="flex items-center gap-2 text-sm">
              <MapPin className="h-4 w-4" />
              <address className="not-italic">
                Dorking Self Store Ltd
                <br />
                Dorking, Surrey
              </address>
            </div>
          </div>

          <div>
            <h3 className="mb-4 text-lg font-bold">Contact Us</h3>
            <ul className="space-y-3 text-sm">
              <li>
                <a href="tel:01306880124" className="flex items-center gap-2 hover:underline">
                  <Phone className="h-4 w-4" />
                  <span>01306 880124</span>
                </a>
              </li>
              <li>
                <a href="mailto:info@dorkingselfstore.co.uk" className="flex items-center gap-2 hover:underline">
                  <Mail className="h-4 w-4" />
                  <span>info@dorkingselfstore.co.uk</span>
                </a>
              </li>
              <li className="flex items-center gap-2">
                <Clock className="h-4 w-4" />
                <span>
                  Mon-Fri: 8am-6pm
                  <br />
                  Sat: 9am-4pm
                  <br />
                  Sun: Closed
                </span>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="mb-4 text-lg font-bold">Quick Links</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/storage-units" className="hover:underline">
                  Storage Units
                </Link>
              </li>
              <li>
                <Link href="/business-storage" className="hover:underline">
                  Business Storage
                </Link>
              </li>
              <li>
                <Link href="/domestic-storage" className="hover:underline">
                  Domestic Storage
                </Link>
              </li>
              <li>
                <Link href="/why-choose-us" className="hover:underline">
                  Why Choose Us
                </Link>
              </li>
              <li>
                <Link href="/faqs" className="hover:underline">
                  FAQs
                </Link>
              </li>
              <li>
                <Link href="/contact" className="hover:underline">
                  Contact
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="mb-4 text-lg font-bold">Legal</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/privacy-policy" className="hover:underline">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link href="/terms-conditions" className="hover:underline">
                  Terms & Conditions
                </Link>
              </li>
              <li>
                <Link href="/cookie-policy" className="hover:underline">
                  Cookie Policy
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-8 border-t border-primary-foreground/20 pt-8 text-center text-sm">
          <p>&copy; {currentYear} Dorking Self Store Ltd. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}
