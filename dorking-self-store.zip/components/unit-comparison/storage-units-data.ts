export interface StorageUnit {
  id: string
  name: string
  dimensions: string
  price: string
  squareFeet: number
  image: string
  typicalContents: string
  popular?: boolean
}

export const storageUnits: StorageUnit[] = [
  {
    id: "small",
    name: "Small Unit",
    dimensions: "25 sq ft (5ft × 5ft)",
    price: "£85/mo",
    squareFeet: 25,
    image: "/placeholder.svg?height=200&width=200",
    typicalContents: "Small furniture items, boxes, seasonal items",
  },
  {
    id: "medium",
    name: "Medium Unit",
    dimensions: "50 sq ft (10ft × 5ft)",
    price: "£157/mo",
    squareFeet: 50,
    image: "/placeholder.svg?height=200&width=200",
    typicalContents: "Contents of a one-bedroom flat",
    popular: true,
  },
  {
    id: "large",
    name: "Large Unit",
    dimensions: "100 sq ft (10ft × 10ft)",
    price: "£295/mo",
    squareFeet: 100,
    image: "/placeholder.svg?height=200&width=200",
    typicalContents: "Contents of a three-bedroom house",
  },
  {
    id: "xlarge",
    name: "Extra Large Unit",
    dimensions: "150 sq ft (15ft × 10ft)",
    price: "£425/mo",
    squareFeet: 150,
    image: "/placeholder.svg?height=200&width=200",
    typicalContents: "Contents of a four-bedroom house",
  },
  {
    id: "garage",
    name: "Garage Unit",
    dimensions: "200 sq ft (20ft × 10ft)",
    price: "£550/mo",
    squareFeet: 200,
    image: "/placeholder.svg?height=200&width=200",
    typicalContents: "Full house contents, large furniture items",
  },
  {
    id: "custom",
    name: "Custom Solution",
    dimensions: "Tailored to your needs",
    price: "Contact us",
    squareFeet: 0,
    image: "/placeholder.svg?height=200&width=200",
    typicalContents: "Custom storage solutions for special requirements",
  },
]
