"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Check } from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import { cn } from "@/lib/utils"
import { storageUnits } from "./storage-units-data"

export default function UnitComparison() {
  const [selectedUnits, setSelectedUnits] = useState<string[]>(["medium", "large"])

  const handleToggleUnit = (unitId: string) => {
    setSelectedUnits((prev) => {
      if (prev.includes(unitId)) {
        return prev.filter((id) => id !== unitId)
      } else {
        // Limit to 3 units for comparison
        if (prev.length >= 3) {
          return [...prev.slice(1), unitId]
        }
        return [...prev, unitId]
      }
    })
  }

  const filteredUnits = storageUnits.filter((unit) => selectedUnits.includes(unit.id))

  return (
    <div className="mx-auto max-w-5xl">
      <div className="mb-6">
        <h2 className="mb-4 text-2xl font-bold">Compare Storage Units</h2>
        <p className="text-muted-foreground">
          Select up to 3 storage unit sizes to compare their features and prices side by side.
        </p>
      </div>

      {/* Unit Selection */}
      <div className="mb-8 grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-5 lg:grid-cols-6">
        {storageUnits.map((unit) => (
          <Button
            key={unit.id}
            variant={selectedUnits.includes(unit.id) ? "default" : "outline"}
            className={cn(
              "h-auto flex-col py-2 text-xs",
              selectedUnits.includes(unit.id) && "border-primary bg-primary text-primary-foreground",
            )}
            onClick={() => handleToggleUnit(unit.id)}
          >
            <span className="font-bold">{unit.name}</span>
            <span className="text-[10px]">{unit.dimensions}</span>
          </Button>
        ))}
      </div>

      {/* Comparison Table */}
      {filteredUnits.length > 0 ? (
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="p-4 text-left font-medium">Features</th>
                    {filteredUnits.map((unit) => (
                      <th key={unit.id} className="p-4 text-center">
                        <div className="flex flex-col items-center">
                          <span className="text-lg font-bold">{unit.name}</span>
                          <span className="text-sm text-muted-foreground">{unit.dimensions}</span>
                        </div>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {/* Image Row */}
                  <tr className="border-b">
                    <td className="p-4 font-medium">Unit Preview</td>
                    {filteredUnits.map((unit) => (
                      <td key={`${unit.id}-image`} className="p-4 text-center">
                        <div className="flex justify-center">
                          <div className="relative h-32 w-32 overflow-hidden rounded-lg">
                            <Image
                              src={unit.image || "/placeholder.svg?height=200&width=200"}
                              alt={unit.name}
                              fill
                              className="object-cover"
                            />
                          </div>
                        </div>
                      </td>
                    ))}
                  </tr>

                  {/* Price Row */}
                  <tr className="border-b">
                    <td className="p-4 font-medium">Monthly Price</td>
                    {filteredUnits.map((unit) => (
                      <td key={`${unit.id}-price`} className="p-4 text-center">
                        <div className="text-xl font-bold">{unit.price}</div>
                        <div className="text-xs text-muted-foreground">First month free!</div>
                      </td>
                    ))}
                  </tr>

                  {/* Square Footage */}
                  <tr className="border-b">
                    <td className="p-4 font-medium">Square Footage</td>
                    {filteredUnits.map((unit) => (
                      <td key={`${unit.id}-sqft`} className="p-4 text-center">
                        {unit.squareFeet} sq ft
                      </td>
                    ))}
                  </tr>

                  {/* Ceiling Height */}
                  <tr className="border-b">
                    <td className="p-4 font-medium">Ceiling Height</td>
                    {filteredUnits.map((unit) => (
                      <td key={`${unit.id}-height`} className="p-4 text-center">
                        8 ft
                      </td>
                    ))}
                  </tr>

                  {/* Cubic Footage */}
                  <tr className="border-b">
                    <td className="p-4 font-medium">Total Volume</td>
                    {filteredUnits.map((unit) => (
                      <td key={`${unit.id}-volume`} className="p-4 text-center">
                        {unit.squareFeet * 8} cubic ft
                      </td>
                    ))}
                  </tr>

                  {/* Typical Contents */}
                  <tr className="border-b">
                    <td className="p-4 font-medium">Typical Contents</td>
                    {filteredUnits.map((unit) => (
                      <td key={`${unit.id}-contents`} className="p-4 text-center">
                        <span className="text-sm">{unit.typicalContents}</span>
                      </td>
                    ))}
                  </tr>

                  {/* Features */}
                  {[
                    "Climate Controlled",
                    "24/7 Security",
                    "Drive-Up Access",
                    "First Month Free",
                    "No Long-Term Contract",
                  ].map((feature) => (
                    <tr key={feature} className="border-b">
                      <td className="p-4 font-medium">{feature}</td>
                      {filteredUnits.map((unit) => (
                        <td key={`${unit.id}-${feature}`} className="p-4 text-center">
                          <Check className="mx-auto h-5 w-5 text-secondary" />
                        </td>
                      ))}
                    </tr>
                  ))}

                  {/* CTA Row */}
                  <tr>
                    <td className="p-4 font-medium">Reserve Now</td>
                    {filteredUnits.map((unit) => (
                      <td key={`${unit.id}-cta`} className="p-4 text-center">
                        <div className="flex flex-col gap-2">
                          <Button asChild size="sm" className="w-full">
                            <a href="tel:01306880124">Call to Reserve</a>
                          </Button>
                          <Button asChild variant="outline" size="sm" className="w-full">
                            <Link href="/contact">Get a Quote</Link>
                          </Button>
                        </div>
                      </td>
                    ))}
                  </tr>
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="rounded-lg border border-dashed p-8 text-center">
          <p className="text-muted-foreground">Please select at least one storage unit to compare.</p>
        </div>
      )}
    </div>
  )
}
