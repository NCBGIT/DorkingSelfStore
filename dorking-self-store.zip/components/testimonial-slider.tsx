"use client"

import { useState, useEffect } from "react"
import { ChevronLeft, ChevronRight, Star } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

interface Testimonial {
  id: number
  name: string
  location: string
  text: string
  rating: number
}

const testimonials: Testimonial[] = [
  {
    id: 1,
    name: "Sarah Johnson",
    location: "Dorking",
    text: "Dorking Self Store has been a lifesaver during our home renovation. The units are clean, secure, and the staff are incredibly helpful. I highly recommend them!",
    rating: 5,
  },
  {
    id: 2,
    name: "James Wilson",
    location: "Reigate",
    text: "As a small business owner, I needed flexible storage for my inventory. The team at Dorking Self Store made the process simple and stress-free. Great service!",
    rating: 5,
  },
  {
    id: 3,
    name: "Emma Thompson",
    location: "Leatherhead",
    text: "I've used several storage facilities over the years, but Dorking Self Store stands out for their exceptional customer service and clean, well-maintained units.",
    rating: 4,
  },
  {
    id: 4,
    name: "Robert Davis",
    location: "Dorking",
    text: "The climate-controlled units are perfect for storing my valuable items. The security is top-notch and I appreciate the flexible access hours.",
    rating: 5,
  },
]

interface TestimonialSliderProps {
  className?: string
}

export default function TestimonialSlider({ className }: TestimonialSliderProps) {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isAutoPlaying, setIsAutoPlaying] = useState(true)

  const nextTestimonial = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % testimonials.length)
  }

  const prevTestimonial = () => {
    setCurrentIndex((prevIndex) => (prevIndex - 1 + testimonials.length) % testimonials.length)
  }

  useEffect(() => {
    if (!isAutoPlaying) return

    const interval = setInterval(() => {
      nextTestimonial()
    }, 5000)

    return () => clearInterval(interval)
  }, [isAutoPlaying])

  return (
    <div
      className={cn("relative overflow-hidden rounded-lg bg-muted p-6", className)}
      onMouseEnter={() => setIsAutoPlaying(false)}
      onMouseLeave={() => setIsAutoPlaying(true)}
    >
      <h2 className="mb-6 text-center text-2xl font-bold">What Our Customers Say</h2>

      <div className="relative h-[200px]">
        {testimonials.map((testimonial, index) => (
          <div
            key={testimonial.id}
            className={cn(
              "absolute inset-0 transition-opacity duration-500",
              index === currentIndex ? "opacity-100" : "opacity-0 pointer-events-none",
            )}
          >
            <div className="flex h-full flex-col justify-between">
              <div>
                <div className="mb-2 flex">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={cn(
                        "h-5 w-5",
                        i < testimonial.rating
                          ? "fill-secondary text-secondary"
                          : "fill-muted-foreground/20 text-muted-foreground/20",
                      )}
                    />
                  ))}
                </div>
                <p className="italic">&ldquo;{testimonial.text}&rdquo;</p>
              </div>

              <div className="mt-4">
                <p className="font-semibold">{testimonial.name}</p>
                <p className="text-sm text-muted-foreground">{testimonial.location}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-4 flex justify-center gap-2">
        <Button
          variant="outline"
          size="icon"
          onClick={prevTestimonial}
          className="h-8 w-8 rounded-full"
          aria-label="Previous testimonial"
        >
          <ChevronLeft className="h-4 w-4" />
        </Button>

        {testimonials.map((_, index) => (
          <Button
            key={index}
            variant="ghost"
            size="icon"
            onClick={() => setCurrentIndex(index)}
            className={cn("h-2 w-2 rounded-full p-0", index === currentIndex ? "bg-primary" : "bg-muted-foreground/20")}
            aria-label={`Go to testimonial ${index + 1}`}
          />
        ))}

        <Button
          variant="outline"
          size="icon"
          onClick={nextTestimonial}
          className="h-8 w-8 rounded-full"
          aria-label="Next testimonial"
        >
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>
    </div>
  )
}
